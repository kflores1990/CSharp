﻿using System;



/*Kyle Flores 02/04/2020*/
namespace _4350Review4
{
    class Program
    {
        static void Main(string[] args)
        {


            //Employee test = new Employee("kyle", "Flores", 123, 15.25, 50);

            EmployeeDemo test2 = new EmployeeDemo();

            Console.ReadLine();

        }
    }
}





/*
You are to create a class object called “Employee” 
which included 
-------------eight private variables:----------------
----firstN 
----lastN 
----idNum
----Wage---- holds how much the person makes per hour 
----WeekHrsWkd---- holds how many total hours the person worked each week. 
----regHrsAmt ----- initialize to a fixed amount of 40 using constructor
----regPay
----otPay
After going over the regular hours, the employee gets 1.5x the wage 
for each additional hour worked.

----------------------Methods-----------------
----constructor
----properties
----CalcPay(): Calculate the regular pay and overtime pay
*/

/*
------------Create an “EmployeeDemo” class. In the main function,------

the program should ask the user the number of employee 
in the company and create a 2-dimensional dynamic array 
(number of employee by 4 weeks). 
Then, the program should ask user to enter each employee’s 
information and the amount of hours they worked weekly
*/

/*
The program shows a menu with employee name for user to choose which 
employee to 
---------display the following information:-----
How much the person totally made
How much of paycheck is regular pay 
How much of paycheck is overtime pay
*/
