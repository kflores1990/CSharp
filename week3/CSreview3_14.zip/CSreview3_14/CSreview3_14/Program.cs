﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSreview3_14
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = 0;
            double[] grades = getInput(ref size);
            calcGrades(grades, size);
        }
        static double[] getInput(ref int numG)
        {
            //int numG;
            Console.Write("Enter the number of grades: ");
            numG = Convert.ToInt32(Console.ReadLine());

            double[] arr = new double[numG];
            for (int i = 0; i < numG; i++)
            {
                Console.Write("\nEnter grade {0}: ", i + 1);
                arr[i] = Convert.ToDouble(Console.ReadLine());
                while (arr[i] < 0 || arr[i] > 100)
                {
                    Console.WriteLine("Error!! The grade has to be between 0 and 100.");
                    Console.Write("\nEnter grade {0}: ", i + 1);
                    arr[i] = Convert.ToDouble(Console.ReadLine());
                }

            }
            return arr;
        }
        public static void calcGrades(double[] arr, int size)
        {
            bool flag = true;
            double temp;
            double total = 0;
            while (flag)
            {
                flag = false;
                for (int i = 0; i < size - 1; i++)
                {
                    if (arr[i] < arr[i + 1])
                    {
                        temp = arr[i];
                        arr[i] = arr[i + 1];
                        arr[i + 1] = temp;
                        flag = true;
                    }
                }
            }
            Console.Clear();
            Console.WriteLine("Highest:   {0}", arr[0]);
            Console.WriteLine("Lowest:    {0}", arr[size - 1]);
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine(arr[i]);
                total += arr[i];
            }
            Console.WriteLine("Average:   {0}", (total / size));

            if ((total / size) >= 90)
                Console.WriteLine("Letter Grade: A");
            else if ((total / size) >= 80)
                Console.WriteLine("Letter Grade: B");
            else if ((total / size) >= 70)
                Console.WriteLine("Letter Grade: C");
            else if ((total / size) >= 60)
                Console.WriteLine("Letter Grade: D");
            else
                Console.WriteLine("Letter Grade: F");
        }
    }
}