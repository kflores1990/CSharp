﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCarLoan2
{
    class Loan
    {
        public int LoanNumber { get; set; }
        public string LastName { get; set; }
        public double LoanAmount { get; set; }

    }
}
