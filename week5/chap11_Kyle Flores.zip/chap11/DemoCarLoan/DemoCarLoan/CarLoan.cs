﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCarLoan
{
    class CarLoan : Loan
    {
        public int Year { get; set; }
        public string Make { get; set; }

    }
}
